# Face_Detection
This program is about face detection which uses raspberry pi ,opencv3, phpmyadmin with mariadb.
